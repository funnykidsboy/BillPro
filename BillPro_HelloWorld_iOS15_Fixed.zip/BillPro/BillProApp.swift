import SwiftUI

@main
struct BillProApp: App {
    var body: some Scene {
        WindowGroup {
            Text("Hello iOS 15")
                .padding()
        }
    }
}
