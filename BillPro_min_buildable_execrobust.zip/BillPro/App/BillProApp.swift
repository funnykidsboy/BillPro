import SwiftUI

@main
struct BillProApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
